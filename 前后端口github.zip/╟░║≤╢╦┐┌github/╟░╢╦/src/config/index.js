export default {
    baseUrl: {
        dev: '/api',
        pro: '/api',
        // assetsSubDirectory: 'static',
        // assetsPublicPath: '/',
        // proxyTable: {
        //     '/api': {
        //         target:'http://localhost:3000', // 你请求的第三方接口
        //         changeOrigin: true,
        //         pathRewrite: {
        //             '^/api': ''  
        //         }
        //     }

        // }
    }
}