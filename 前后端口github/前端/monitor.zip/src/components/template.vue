<template>
  <div class="container"></div>
</template>
<script>
export default {
  name: "template1",
  components: {

  },
  data() {
    return {};
  },
  methods: {},
  created(){

  },
  mounted(){

  }
};
</script>
<style scoped>
</style>